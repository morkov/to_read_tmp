1). Чтобы все примеры компилялись и работали нужен один extension(Numeric)
    Взять его можно здесь: http://opensource.adobe.com/wiki/display/gil/Downloads
    Затем распаковать и положить его в /usr/include/boost/gil/extensions
2). Чтобы все и правда компилялось, нужно немного поправить код Numeric:
    в файле:  /usr/include/boost/gil/extensions/numeric/sampler.hpp
    заменить все point2<int> на point2<std::ptrdiff_t> (строки 48 и 104)
