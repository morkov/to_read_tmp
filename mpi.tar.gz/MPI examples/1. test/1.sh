#!/bin/bash
echo 'qqq'
echo $@
