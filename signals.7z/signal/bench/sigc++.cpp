#include <iostream>
#include <sigc++/signal.h>
#include <sigc++/connection.h>

int counter = 0;

// Functee
struct Slot
{
	void operator()()
	{
		counter++;
//		std::cout << counter << std::endl;
	}
};

int main(void)
{
	sigc::signal <void> sign;
	Slot sl;
	for(int i = 0; i < 1000000; ++i)
	{
		sigc::connection c = sign.connect(sl);
		sign();
		c.disconnect();
	}

	std::cout << "Invoked " << counter << " times" << std::endl;
	return 0;
}
