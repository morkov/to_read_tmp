#include <iostream>
#include <boost/signals.hpp>

int counter = 0;

// Functee
struct Slot
{
	void operator()()
	{
		counter++;
//		std::cout << counter << std::endl;
	}
};

int main(void)
{
	boost::signal<void ()> sign;
	Slot sl;
	for(int i = 0; i < 1000000; ++i)
	{
		boost::signals::connection c = sign.connect(sl);
		sign();
		c.disconnect();
	}

	std::cout << "Invoked " << counter << " times" << std::endl;
	return 0;
}
