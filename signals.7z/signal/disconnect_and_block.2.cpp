// Various simple examples involving disconnecting and blocking slots.
// Copyright Douglas Gregor 2001-2004.
// Copyright Frank Mori Hess 2009.
//
// Use, modification and
// distribution is subject to the Boost Software License, Version
// 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
// For more information, see http://www.boost.org

#include <iostream>
#include <boost/signals2/signal.hpp>
#include <boost/signals2/connection.hpp>
#include <boost/signals2/shared_connection_block.hpp>

boost::signals2::connection c;
boost::signals2::signal<void()> * sig_p;

void additional()
{
	std::cout << "SUDDENLY!!" << std::endl;
}

void foo()
{
	std::cout << "foo";
	sig_p -> connect(&additional);
}
void disconn()
{
	std::cout << " disconnect\n";
	c.disconnect();
	sig_p->operator()();

}
void blocker()
{
	std::cout << " blocker\n";
	{
		boost::signals2::shared_connection_block bl(c);

		sig_p->operator()();
	}
}


void disconnect_by_slot_example()
{
	boost::signals2::signal<void()> sig;
	sig_p = &sig;

	sig.connect(&foo);
	c = sig.connect(&disconn);
	sig();
}

void block_by_slot_example()
{
	boost::signals2::signal<void()> sig;
	sig_p = &sig;

	sig.connect(&foo);
	c = sig.connect(&blocker);
	sig();
}

int main()
{
	std::cout << "\nDisconnect by slot example:\n";
	disconnect_by_slot_example();

	std::cout << "\nBlock by slot example:\n";
	block_by_slot_example();

	return 0;
}
;
