#include <iostream>
#include <boost/signals2.hpp>

using namespace boost::signals2;

// Functee
struct helloWorld
{
	void operator()()
	{
		std::cout << "Hello, world!" << std::endl;
	}
};

int main(void)
{
	boost::signals2::signal<void ()> sign;
	sign.connect(helloWorld());

	sign();

	return 0;
}
