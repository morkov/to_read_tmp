#include <iostream>
#include <boost/signals2.hpp>

using namespace boost::signals2;

// Functee
struct Hello
{
	void operator()()
	{
		std::cout << "Hello ";
	}
};
struct World
{
	void operator()()
	{
		std::cout << " World!" << std::endl;
	}
};

int main(void)
{
	boost::signals2::signal<void ()> sign;
	sign.connect(Hello());
	sign.connect(World());

	sign();

	return 0;
}
